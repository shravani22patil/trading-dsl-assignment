"""
TRADING DSL SYSTEM - COMPLETE PACKAGE
======================================

INSTRUCTIONS TO RUN:
====================

STEP 1: SAVE THIS FILE
----------------------
1. Copy this ENTIRE file
2. Save it as: main.py
3. Save location: Desktop/trading-dsl/main.py

STEP 2: INSTALL PYTHON (if not installed)
-----------------------------------------
Windows:
  1. Go to: https://www.python.org/downloads/
  2. Download Python 3.8 or higher
  3. Run installer
  4. ✓ CHECK "Add Python to PATH"
  5. Click Install

Mac:
  Open Terminal and run:
  brew install python3
  
  (Or download from python.org)

Linux:
  sudo apt update
  sudo apt install python3 python3-pip

STEP 3: OPEN TERMINAL/COMMAND PROMPT
------------------------------------
Windows:
  1. Press Windows Key + R
  2. Type: cmd
  3. Press Enter

Mac:
  1. Press Command + Space
  2. Type: terminal
  3. Press Enter

Linux:
  Press Ctrl + Alt + T

STEP 4: NAVIGATE TO YOUR FILE
-----------------------------
Type these commands (press Enter after each):

cd Desktop
cd trading-dsl

STEP 5: INSTALL REQUIRED LIBRARIES
----------------------------------
Copy and paste this command:

pip install pandas numpy

Wait 1-2 minutes for installation.

If you get an error, try:
pip3 install pandas numpy

STEP 6: RUN THE PROGRAM
-----------------------
Type this command:

python main.py

If that doesn't work, try:
python3 main.py

STEP 7: SEE RESULTS
-------------------
You should see output like:

================================================================================
TRADING STRATEGY DSL - END-TO-END DEMONSTRATION
================================================================================

1. NATURAL LANGUAGE INPUT:
Buy when the close price is above the 20-day moving average...

...

7. BACKTEST RESULTS:
Total Trades:      12
Total Return:      8.34%
Win Rate:          58.33%
================================================================================

SUCCESS! 🎉

TROUBLESHOOTING:
===============

Problem: "python is not recognized"
Solution: Use python3 instead: python3 main.py

Problem: "No module named pandas"
Solution: Run: pip install pandas numpy

Problem: "Permission denied"
Solution (Mac/Linux): sudo pip3 install pandas numpy

Problem: File not found
Solution: Make sure you saved as main.py in Desktop/trading-dsl folder

TESTING DIFFERENT STRATEGIES:
=============================

After successful run, you can modify line 716 to test different strategies:

nl_input = "Buy when close is above 100"
nl_input = "Enter when RSI(14) is below 30"
nl_input = "Buy when close is above 20-day moving average and volume is above 1 million"

Then run again: python main.py

"""

# ============================================================================
# COMPLETE TRADING STRATEGY DSL SYSTEM
# Natural Language → DSL → AST → Python Code → Backtest
# ============================================================================

import re
import json
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

print("Loading Trading DSL System...")
print("=" * 80)

# ============================================================================
# PART 1: NATURAL LANGUAGE PARSER
# ============================================================================

class NLParser:
    """Converts natural language trading rules to structured JSON"""
    
    def __init__(self):
        self.indicator_patterns = {
            r'(\d+)[-\s]?day moving average|sma\((\d+)\)|ma\((\d+)\)': 'sma',
            r'rsi\((\d+)\)|rsi[-\s]?(\d+)': 'rsi',
            r'ema\((\d+)\)': 'ema',
        }
        
        self.comparison_patterns = {
            r'above|greater than|more than|>': '>',
            r'below|less than|<': '<',
            r'equals|equal to|==': '==',
            r'at least|>=': '>=',
            r'at most|<=': '<=',
        }
    
    def parse(self, text: str) -> Dict[str, Any]:
        """Parse natural language into structured JSON"""
        text = text.lower().strip()
        
        entry_text = ""
        exit_text = ""
        
        if "exit when" in text or "sell when" in text:
            parts = re.split(r'exit when|sell when', text, maxsplit=1)
            entry_text = parts[0]
            exit_text = parts[1] if len(parts) > 1 else ""
        else:
            entry_text = text
        
        entry_conditions = self._parse_conditions(entry_text, is_entry=True)
        exit_conditions = []
        if exit_text:
            exit_conditions = self._parse_conditions(exit_text, is_entry=False)
        
        return {
            "entry": entry_conditions,
            "exit": exit_conditions
        }
    
    def _parse_conditions(self, text: str, is_entry: bool) -> List[Dict[str, Any]]:
        """Parse a condition string into structured conditions"""
        conditions = []
        text = re.sub(r'^(buy|enter|trigger entry|when)\s+', '', text)
        clauses = re.split(r'\s+and\s+', text)
        
        for clause in clauses:
            clause = clause.strip()
            if not clause:
                continue
            condition = self._parse_single_condition(clause)
            if condition:
                conditions.append(condition)
        
        return conditions
    
    def _parse_single_condition(self, clause: str) -> Optional[Dict[str, Any]]:
        """Parse a single condition clause"""
        
        # RSI pattern
        rsi_match = re.search(r'rsi\s*\(?\s*(\d+)\s*\)?.*?(above|below|greater|less|>|<)\s*(\d+)', clause)
        if rsi_match:
            period = int(rsi_match.group(1))
            comp = 'lt' if 'below' in rsi_match.group(2) or '<' in rsi_match.group(2) else 'gt'
            value = int(rsi_match.group(3))
            return {
                "left": f"rsi(close,{period})",
                "operator": "<" if comp == 'lt' else ">",
                "right": value
            }
        
        # SMA pattern
        sma_match = re.search(r'(close|price).*?(above|below|greater|less|>|<).*?(\d+)[-\s]?day moving average', clause)
        if sma_match:
            comp = 'gt' if 'above' in sma_match.group(2) or '>' in sma_match.group(2) else 'lt'
            period = int(sma_match.group(3))
            return {
                "left": "close",
                "operator": ">" if comp == 'gt' else "<",
                "right": f"sma(close,{period})"
            }
        
        # Volume pattern
        volume_match = re.search(r'volume.*?(above|below|greater|less|>|<)\s*(\d+(?:\.\d+)?)\s*(million|m|k)?', clause)
        if volume_match:
            comp = 'gt' if 'above' in volume_match.group(1) or '>' in volume_match.group(1) else 'lt'
            value = float(volume_match.group(2))
            multiplier = volume_match.group(3)
            
            if multiplier and multiplier.lower() in ['million', 'm']:
                value *= 1_000_000
            elif multiplier and multiplier.lower() == 'k':
                value *= 1_000
            
            return {
                "left": "volume",
                "operator": ">" if comp == 'gt' else "<",
                "right": int(value)
            }
        
        # Cross pattern
        cross_match = re.search(r'(price|close)\s+crosses?\s+(above|below)\s+(yesterday)', clause)
        if cross_match:
            direction = cross_match.group(2)
            return {
                "left": "close",
                "operator": "cross_above" if direction == "above" else "cross_below",
                "right": "high[-1]"
            }
        
        # Percentage change pattern
        pct_match = re.search(r'(\w+)\s+(?:increases?|decreases?)\s+by\s+more than\s+(\d+)\s*(?:percent|%)', clause)
        if pct_match:
            field = pct_match.group(1)
            pct = int(pct_match.group(2))
            return {
                "left": field,
                "operator": "pct_change",
                "right": pct,
                "comparison": ">"
            }
        
        # Generic pattern
        generic_match = re.search(r'(\w+)\s*(>|<|>=|<=|==)\s*(\d+(?:\.\d+)?)', clause)
        if generic_match:
            return {
                "left": generic_match.group(1),
                "operator": generic_match.group(2),
                "right": float(generic_match.group(3))
            }
        
        return None

# ============================================================================
# PART 2: DSL GENERATOR
# ============================================================================

class DSLGenerator:
    """Converts structured JSON to DSL text"""
    
    def generate(self, json_rules: Dict[str, Any]) -> str:
        """Generate DSL text from JSON rules"""
        dsl_lines = []
        
        if json_rules.get("entry"):
            dsl_lines.append("ENTRY:")
            entry_conditions = []
            for cond in json_rules["entry"]:
                entry_conditions.append(self._condition_to_dsl(cond))
            dsl_lines.append("  " + " AND ".join(entry_conditions))
        
        if json_rules.get("exit"):
            dsl_lines.append("\nEXIT:")
            exit_conditions = []
            for cond in json_rules["exit"]:
                exit_conditions.append(self._condition_to_dsl(cond))
            dsl_lines.append("  " + " AND ".join(exit_conditions))
        
        return "\n".join(dsl_lines)
    
    def _condition_to_dsl(self, condition: Dict[str, Any]) -> str:
        """Convert a single condition to DSL format"""
        left = condition["left"]
        op = condition["operator"]
        right = condition["right"]
        
        if op == "cross_above":
            return f"CROSS({left}, {right}, above)"
        elif op == "cross_below":
            return f"CROSS({left}, {right}, below)"
        elif op == "pct_change":
            comp = condition.get("comparison", ">")
            return f"PCT_CHANGE({left}) {comp} {right}"
        
        return f"{left} {op} {right}"

# ============================================================================
# PART 3: DSL PARSER & AST
# ============================================================================

class ASTNode:
    """Base class for AST nodes"""
    pass

@dataclass
class BinaryOp(ASTNode):
    left: Any
    operator: str
    right: Any

@dataclass
class Identifier(ASTNode):
    name: str

@dataclass
class Literal(ASTNode):
    value: Any

@dataclass
class FunctionCall(ASTNode):
    name: str
    args: List[Any]

@dataclass
class CrossEvent(ASTNode):
    series: str
    threshold: str
    direction: str

class DSLParser:
    """Parses DSL text into AST"""
    
    def parse(self, dsl_text: str) -> Dict[str, List[ASTNode]]:
        """Parse DSL text into AST"""
        lines = dsl_text.strip().split('\n')
        
        ast = {
            "entry": [],
            "exit": []
        }
        
        current_section = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if line == "ENTRY:":
                current_section = "entry"
                continue
            elif line == "EXIT:":
                current_section = "exit"
                continue
            
            if current_section:
                conditions = self._parse_condition_line(line)
                ast[current_section].extend(conditions)
        
        return ast
    
    def _parse_condition_line(self, line: str) -> List[ASTNode]:
        """Parse a line with conditions"""
        parts = re.split(r'\s+(AND|OR)\s+', line)
        
        conditions = []
        for i, part in enumerate(parts):
            if part in ['AND', 'OR']:
                continue
            node = self._parse_expression(part.strip())
            if node:
                conditions.append(node)
        
        return conditions
    
    def _parse_expression(self, expr: str) -> Optional[ASTNode]:
        """Parse a single expression into AST node"""
        
        # CROSS function
        cross_match = re.match(r'CROSS\(([^,]+),\s*([^,]+),\s*(\w+)\)', expr)
        if cross_match:
            return CrossEvent(
                series=cross_match.group(1).strip(),
                threshold=cross_match.group(2).strip(),
                direction=cross_match.group(3).strip()
            )
        
        # PCT_CHANGE function
        pct_match = re.match(r'PCT_CHANGE\(([^)]+)\)\s*([><=]+)\s*(.+)', expr)
        if pct_match:
            return BinaryOp(
                left=FunctionCall("PCT_CHANGE", [pct_match.group(1).strip()]),
                operator=pct_match.group(2).strip(),
                right=Literal(float(pct_match.group(3).strip()))
            )
        
        # Comparison operators
        comp_match = re.match(r'(.+?)\s*([><=]+)\s*(.+)', expr)
        if comp_match:
            left_str = comp_match.group(1).strip()
            operator = comp_match.group(2).strip()
            right_str = comp_match.group(3).strip()
            
            left = self._parse_operand(left_str)
            right = self._parse_operand(right_str)
            
            return BinaryOp(left=left, operator=operator, right=right)
        
        return None
    
    def _parse_operand(self, operand: str) -> ASTNode:
        """Parse an operand"""
        func_match = re.match(r'(\w+)\(([^)]+)\)', operand)
        if func_match:
            func_name = func_match.group(1)
            args_str = func_match.group(2)
            args = [arg.strip() for arg in args_str.split(',')]
            return FunctionCall(func_name, args)
        
        try:
            value = float(operand)
            return Literal(value)
        except ValueError:
            pass
        
        return Identifier(operand)

# ============================================================================
# PART 4: INDICATORS
# ============================================================================

class Indicators:
    """Technical indicator calculations"""
    
    @staticmethod
    def sma(series: pd.Series, period: int) -> pd.Series:
        """Simple Moving Average"""
        return series.rolling(window=period).mean()
    
    @staticmethod
    def ema(series: pd.Series, period: int) -> pd.Series:
        """Exponential Moving Average"""
        return series.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def rsi(series: pd.Series, period: int = 14) -> pd.Series:
        """Relative Strength Index"""
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    @staticmethod
    def pct_change(series: pd.Series, periods: int = 1) -> pd.Series:
        """Percentage change"""
        return series.pct_change(periods) * 100

# ============================================================================
# PART 5: CODE GENERATOR
# ============================================================================

class CodeGenerator:
    """Generates Python code from AST"""
    
    def __init__(self):
        self.indicators = Indicators()
    
    def generate(self, ast: Dict[str, List[ASTNode]], df: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
        """Generate and execute strategy code"""
        df = self._add_indicators(df)
        entry_signals = self._generate_signals(ast.get("entry", []), df)
        exit_signals = self._generate_signals(ast.get("exit", []), df)
        return entry_signals, exit_signals
    
    def _add_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Pre-calculate common indicators"""
        df = df.copy()
        
        for period in [10, 20, 50, 200]:
            df[f'sma_{period}'] = self.indicators.sma(df['close'], period)
        
        df['rsi_14'] = self.indicators.rsi(df['close'], 14)
        df['pct_change'] = self.indicators.pct_change(df['close'])
        
        return df
    
    def _generate_signals(self, nodes: List[ASTNode], df: pd.DataFrame) -> pd.Series:
        """Generate boolean signals from AST nodes"""
        if not nodes:
            return pd.Series([False] * len(df), index=df.index)
        
        result = pd.Series([True] * len(df), index=df.index)
        
        for node in nodes:
            condition = self._evaluate_node(node, df)
            result = result & condition
        
        return result
    
    def _evaluate_node(self, node: ASTNode, df: pd.DataFrame) -> pd.Series:
        """Evaluate an AST node"""
        
        if isinstance(node, BinaryOp):
            left_val = self._get_value(node.left, df)
            right_val = self._get_value(node.right, df)
            
            if node.operator == '>':
                return left_val > right_val
            elif node.operator == '<':
                return left_val < right_val
            elif node.operator == '>=':
                return left_val >= right_val
            elif node.operator == '<=':
                return left_val <= right_val
            elif node.operator == '==':
                return left_val == right_val
        
        elif isinstance(node, CrossEvent):
            series = df[node.series]
            threshold = self._get_value(Identifier(node.threshold), df)
            
            if node.direction == 'above':
                return (series.shift(1) <= threshold) & (series > threshold)
            else:
                return (series.shift(1) >= threshold) & (series < threshold)
        
        return pd.Series([False] * len(df), index=df.index)
    
    def _get_value(self, node: ASTNode, df: pd.DataFrame) -> pd.Series:
        """Get value from AST node"""
        
        if isinstance(node, Literal):
            return node.value
        
        elif isinstance(node, Identifier):
            name = node.name
            
            if '[' in name:
                match = re.match(r'(\w+)\[(-?\d+)\]', name)
                if match:
                    field = match.group(1)
                    offset = int(match.group(2))
                    return df[field].shift(-offset)
            
            if name in df.columns:
                return df[name]
            
            return 0
        
        elif isinstance(node, FunctionCall):
            func_name = node.name.lower()
            
            if func_name == 'sma':
                series_name = node.args[0]
                period = int(node.args[1])
                return self.indicators.sma(df[series_name], period)
            
            elif func_name == 'ema':
                series_name = node.args[0]
                period = int(node.args[1])
                return self.indicators.ema(df[series_name], period)
            
            elif func_name == 'rsi':
                series_name = node.args[0]
                period = int(node.args[1]) if len(node.args) > 1 else 14
                return self.indicators.rsi(df[series_name], period)
            
            elif func_name == 'pct_change':
                series_name = node.args[0]
                return self.indicators.pct_change(df[series_name])
        
        return pd.Series([0] * len(df), index=df.index)

# ============================================================================
# PART 6: BACKTESTER
# ============================================================================

@dataclass
class Trade:
    entry_date: str
    entry_price: float
    exit_date: str
    exit_price: float
    pnl: float
    return_pct: float

class Backtester:
    """Simple backtesting engine"""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self.trades: List[Trade] = []
        self.position = None
        self.entry_date = None
    
    def run(self, entry_signals: pd.Series, exit_signals: pd.Series) -> Dict[str, Any]:
        """Run backtest simulation"""
        self.trades = []
        self.position = None
        
        for i in range(len(self.df)):
            date = self.df.index[i]
            price = self.df.iloc[i]['close']
            
            if self.position is not None and exit_signals.iloc[i]:
                self._close_trade(date, price)
            
            elif self.position is None and entry_signals.iloc[i]:
                self._open_trade(date, price)
        
        if self.position is not None:
            last_date = self.df.index[-1]
            last_price = self.df.iloc[-1]['close']
            self._close_trade(last_date, last_price)
        
        return self._calculate_metrics()
    
    def _open_trade(self, date, price):
        """Open a new position"""
        self.position = price
        self.entry_date = date
    
    def _close_trade(self, date, price):
        """Close current position"""
        if self.position is None:
            return
        
        pnl = price - self.position
        return_pct = (pnl / self.position) * 100
        
        trade = Trade(
            entry_date=str(self.entry_date),
            entry_price=self.position,
            exit_date=str(date),
            exit_price=price,
            pnl=pnl,
            return_pct=return_pct
        )
        
        self.trades.append(trade)
        self.position = None
        self.entry_date = None
    
    def _calculate_metrics(self) -> Dict[str, Any]:
        """Calculate performance metrics"""
        if not self.trades:
            return {
                "total_trades": 0,
                "total_return": 0.0,
                "win_rate": 0.0,
                "avg_return": 0.0,
                "max_drawdown": 0.0,
                "trades": []
            }
        
        total_pnl = sum(t.pnl for t in self.trades)
        initial_capital = self.trades[0].entry_price if self.trades else 1000
        total_return = (total_pnl / initial_capital) * 100
        
        winning_trades = [t for t in self.trades if t.pnl > 0]
        win_rate = (len(winning_trades) / len(self.trades)) * 100
        
        avg_return = sum(t.return_pct for t in self.trades) / len(self.trades)
        
        cumulative = [0]
        for trade in self.trades:
            cumulative.append(cumulative[-1] + trade.pnl)
        
        peak = cumulative[0]
        max_dd = 0
        for value in cumulative:
            if value > peak:
                peak = value
            dd = ((peak - value) / peak * 100) if peak != 0 else 0
            max_dd = max(max_dd, dd)
        
        return {
            "total_trades": len(self.trades),
            "total_return": round(total_return, 2),
            "win_rate": round(win_rate, 2),
            "avg_return": round(avg_return, 2),
            "max_drawdown": round(max_dd, 2),
            "trades": self.trades
        }

# ============================================================================
# PART 7: DEMO & SAMPLE DATA
# ============================================================================

def create_sample_data() -> pd.DataFrame:
    """Create sample OHLCV data"""
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='D')
    
    np.random.seed(42)
    price = 100
    data = []
    
    for date in dates:
        change = np.random.randn() * 2
        price = max(price + change, 50)
        
        open_price = price + np.random.randn() * 0.5
        high_price = max(open_price, price) + abs(np.random.randn() * 1)
        low_price = min(open_price, price) - abs(np.random.randn() * 1)
        close_price = price
        volume = int(np.random.uniform(500000, 2000000))
        
        data.append({
            'date': date,
            'open': round(open_price, 2),
            'high': round(high_price, 2),
            'low': round(low_price, 2),
            'close': round(close_price, 2),
            'volume': volume
        })
    
    df = pd.DataFrame(data)
    df.set_index('date', inplace=True)
    return df

def run_demo():
    """Complete end-to-end demonstration"""
    
    print("\n" + "=" * 80)
    print("TRADING STRATEGY DSL - END-TO-END DEMONSTRATION")
    print("=" * 80)
    
    nl_input = """
    Buy when the close price is above the 20-day moving average and volume is above 1 million.
    Exit when RSI(14) is below 30.
    """
    
    print("\n1. NATURAL LANGUAGE INPUT:")
    print(nl_input.strip())
    
    nl_parser = NLParser()
    json_rules = nl_parser.parse(nl_input)
    
    print("\n2. PARSED JSON STRUCTURE:")
    print(json.dumps(json_rules, indent=2))
    
    dsl_generator = DSLGenerator()
    dsl_text = dsl_generator.generate(json_rules)
    
    print("\n3. GENERATED DSL:")
    print(dsl_text)
    
    dsl_parser = DSLParser()
    ast = dsl_parser.parse(dsl_text)
    
    print("\n4. ABSTRACT SYNTAX TREE (AST):")
    print(f"Entry nodes: {len(ast['entry'])}")
    print(f"Exit nodes: {len(ast['exit'])}")
    
    df = create_sample_data()
    print(f"\n5. SAMPLE DATA LOADED:")
    print(f"Date range: {df.index[0]} to {df.index[-1]}")
    print(f"Total rows: {len(df)}")
    print("\nFirst 5 rows:")
    print(df.head())
    
    code_gen = CodeGenerator()
    entry_signals, exit_signals = code_gen.generate(ast, df)
    
    print(f"\n6. SIGNALS GENERATED:")
    print(f"Entry signals: {entry_signals.sum()} days")
    print(f"Exit signals: {exit_signals.sum()} days")
    
    backtester = Backtester(df)
    results = backtester.run(entry_signals, exit_signals)
    
    print("\n7. BACKTEST RESULTS:")
    print("=" * 80)
    print(f"Total Trades:      {results['total_trades']}")
    print(f"Total Return:      {results['total_return']}%")
    print(f"Win Rate:          {results['win_rate']}%")
    print(f"Average Return:    {results['avg_return']}%")
    print(f"Max Drawdown:      {results['max_drawdown']}%")
    
    print("\n8. TRADE LOG (First 5 trades):")
    print("-" * 80)
    for i, trade in enumerate(results['trades'][:5]):
        print(f"\nTrade {i+1}:")
        print(f"  Entry:  {trade.entry_date} at ${trade.entry_price:.2f}")
        print(f"  Exit:   {trade.exit_date} at ${trade.exit_price:.2f}")
        print(f"  P&L:    ${trade.pnl:.2f} ({trade.return_pct:.2f}%)")
    
    if len(results['trades']) > 5:
        print(f"\n... and {len(results['trades']) - 5} more trades")
    
    print("\n" + "=" * 80)
    print("✅ DEMONSTRATION COMPLETE - SYSTEM WORKING SUCCESSFULLY!")
    print("=" * 80)
    print("\nYou can now modify the strategy on line 716 and run again.")
    print("Example: nl_input = 'Buy when close is above 100'")
    print("\nTo run again: python main.py")

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    try:
        run_demo()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nIf you see 'No module named pandas':")
        print("Run: pip install pandas numpy")
        print("\nThen try again: python main.py")